# Time assessment 

A Pen created on CodePen.io. Original URL: [https://codepen.io/hastings26/pen/dyxWvVE](https://codepen.io/hastings26/pen/dyxWvVE).

